# PCL-Bench Mac handoff

Extract the archive. Keep `install-mac.command` beside `pcl-bench.bundle`. The bundle contains Git history, source code, an article, figures, citations, results and all static site assets. The Python standard library and Git handle local setup. Prerequisites are Python 3.9+, Git, a local Git author identity and a clean personal-site checkout on main or master.

## Install and preview locally

From the extracted directory:

```bash
bash install-mac.command
python3 -m http.server 8000 --directory /Users/xieguo/Documents/identity/michaelyeah7.github.io
```

Open <http://localhost:8000/pcl-bench/>. The installation clones the research repository into `/Users/xieguo/Projects/DREAM_Project/Lucks_Lab/pcl-bench`. It copies the static release into the personal Pages checkout, adds an **Explore PCL-Bench** button next to **See DREAM Brain** and commits those files locally. Local install can be repeated for this release. Existing unrecognized destination content, dirty checkouts or differing project-site releases require manual reconciliation. A failed check leaves your prior files available. A fully prepared project checkout may exist even if a website check subsequently fails.

## Publish from the Mac

With GitHub CLI authenticated as `michaelyeah7` and Git pushes authorized for the personal website:

```bash
bash install-mac.command --publish
```

This creates a **public** GitHub repository named `michaelyeah7/pcl-bench` if needed, pushes the benchmark main branch and pushes the website commit to the existing personal-site branch. It uses ordinary fast-forward pushes. It checks both fetch and push URLs. An existing repository whose main branch diverges, an unexpected remote, or unrelated unpublished personal-site commits stops publication. The personal homepage is served at <https://michaelyeah7.github.io/> and the new project path is <https://michaelyeah7.github.io/pcl-bench/> after the existing Pages workflow deploys. Inspect GitHub Pages or Actions for deployment status.

## Inspect the source or choose alternate paths

```bash
git bundle list-heads pcl-bench.bundle
bash install-mac.command --project /path/to/new/pcl-bench --personal /path/to/personal-checkout
```

In a release checkout, run `python3 tools/release.py build /path/to/new/site` to export a standalone Pages tree from **committed HEAD**. Its `downloads/pcl-bench.zip` is built from tracked files and excludes the nested download. The full Git bundle lives outside the project tree. A source ZIP unpacked without Git metadata can run the simulator directly; creating another source release requires a Git checkout.

## Create the handoff archive

After committing all code, catalog, paper and website files on main, run the following in the research repo. Use a new output directory outside the Git checkout. Check the wrapper filenames before distributing it.

```bash
handoff_dir="$(mktemp -d)"
cp distribution/install-mac.command "$handoff_dir/"
cp distribution/README.md "$handoff_dir/README.md"
git bundle create "$handoff_dir/pcl-bench.bundle" refs/heads/main
(cd "$handoff_dir" && zip PCL-Bench-Mac.zip install-mac.command README.md pcl-bench.bundle)
```
