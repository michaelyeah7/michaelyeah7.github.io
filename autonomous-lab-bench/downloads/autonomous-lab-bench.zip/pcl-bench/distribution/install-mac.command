#!/bin/bash
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd -P)"
bundle="$here/pcl-bench.bundle"
project="/Users/xieguo/Projects/DREAM_Project/Lucks_Lab/pcl-bench"
personal="/Users/xieguo/Documents/identity/michaelyeah7.github.io"
publish=0
while [ "$#" -gt 0 ]; do
  case "$1" in
    --project) project="$2"; shift 2 ;;
    --personal) personal="$2"; shift 2 ;;
    --publish) publish=1; shift ;;
    --help|-h) echo 'Usage: install-mac.command [--project PATH] [--personal PATH] [--publish]'; exit 0 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
done
test -f "$bundle" || { echo "Missing $bundle" >&2; exit 1; }
command -v git >/dev/null
python3 -c 'import sys; sys.exit(sys.version_info < (3,9))' || { echo 'Python 3.9+ is required.' >&2; exit 1; }
if [ "$publish" -eq 1 ]; then command -v gh >/dev/null || { echo 'Publishing requires GitHub CLI (gh).' >&2; exit 1; }; fi
sha="$(git bundle list-heads "$bundle" refs/heads/main | awk '{print $1}')"
test -n "$sha" || { echo 'Bundle does not contain the main branch.' >&2; exit 1; }
# Refuse to nest repositories or modify an unexpected website working tree.
python3 - "$project" "$personal" <<'PY'
from pathlib import Path
import sys
p, w = (Path(a).expanduser().resolve() for a in sys.argv[1:])
if p == w or w in p.parents or p in w.parents:
    sys.exit('Project and personal-site working trees must be separate directories.')
PY
if [ ! -d "$personal/.git" ] && [ ! -f "$personal/.git" ]; then echo "Expected personal Git checkout at $personal" >&2; exit 1; fi
if [ -n "$(git -C "$personal" status --porcelain --untracked-files=all)" ]; then echo 'Personal site contains local changes. Preserve them before running.' >&2; exit 1; fi
if [ -e "$project" ] || [ -L "$project" ]; then
  if [ -L "$project" ] || { [ ! -d "$project/.git" ] && [ ! -f "$project/.git" ]; }; then
    echo "Existing path is not an ordinary Git checkout: $project" >&2; exit 1
  fi
  if [ -n "$(git -C "$project" status --porcelain --untracked-files=all)" ]; then echo 'Project contains local changes. Preserve them before running.' >&2; exit 1; fi
  test "$(git -C "$project" symbolic-ref --short HEAD)" = main || { echo 'Expected project branch main.' >&2; exit 1; }
  if [ "$(git -C "$project" rev-parse HEAD)" != "$sha" ]; then
    git -C "$project" fetch --no-tags "$bundle" refs/heads/main
    git -C "$project" merge-base --is-ancestor HEAD FETCH_HEAD || { echo 'Existing checkout has unrelated or newer commits. Nothing was overwritten.' >&2; exit 1; }
    git -C "$project" merge --ff-only FETCH_HEAD
  fi
else
  mkdir -p "$(dirname "$project")"
  git clone --quiet --branch main "$bundle" "$project"
  git -C "$project" remote remove origin
fi
python3 "$project/tools/release.py" prepare-personal --personal "$personal"
echo "Project: $project"
echo "Personal site: $personal/pcl-bench/"
if [ "$publish" -eq 1 ]; then
  python3 "$project/tools/release.py" publish --personal "$personal"
else
  echo 'Both local repositories are ready. To publish from the authenticated Mac, rerun with --publish.'
fi
