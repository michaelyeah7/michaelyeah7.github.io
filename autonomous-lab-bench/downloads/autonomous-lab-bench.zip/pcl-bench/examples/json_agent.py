"""Exercise the public JSON subprocess protocol. Run in the repository root."""
import json
import subprocess
import sys


def policy(observation):
    """A source-meter policy using only fields visible to any external agent."""
    if not observation['configured']:
        return {'op': 'configure', 'settings': {'compliance_v': 2}}
    if observation['fault']:
        return {'op': 'recover', 'procedure': observation['recovery_operation']}
    readings = {r['point']: r['value'] for r in observation['readings']}
    for current in observation['points']:
        if current not in readings:
            return {'op': 'measure', 'point': current}
    slope = (readings[1] - readings[-1]) / 0.002
    return {'op': 'submit', 'estimate': slope}


def main():
    command = [sys.executable, '-m', 'pclbench', 'session', 'iv-resistance', '--seed', '3']
    with subprocess.Popen(command, text=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE) as process:
        for line in process.stdout:
            reply = json.loads(line)
            observation = reply['observation']
            if observation['done']:
                print(json.dumps(observation['result'], indent=2))
                break
            process.stdin.write(json.dumps(policy(observation)) + '\n')
            process.stdin.flush()


if __name__ == '__main__':
    main()
