"""Original synthetic fixture illustrating a partner's private adapter."""
from pclbench import Environment, Task, register_task


def transmission(rng, point):
    dark = rng.uniform(2, 5)
    reference = rng.uniform(85, 95)
    fraction = rng.uniform(0.30, 0.55)
    signal = {'dark': dark, 'reference': reference, 'film': dark + fraction*(reference-dark)}
    return signal[point], 100*fraction


def register():
    return register_task(
        'example-thin-film-transmission',
        Task(label='Thin-film transmission', instrument='optical_bench',
             objective='Report percent transmission after dark correction.',
             unit='%', tolerance=0.1, points=('dark', 'reference', 'film'),
             limits={'exposure_ms': (1, 20)}, fault='shutter stuck',
             recovery='cycle_shutter', model=transmission),
        node='Illustrative partner profile', source='examples/node_adapter.py',
        permission='Original synthetic fixture, MIT', validation='synthetic')


if __name__ == '__main__':
    import json
    env = Environment(register(), seed=11)
    print(json.dumps(env.observe(), indent=2))
