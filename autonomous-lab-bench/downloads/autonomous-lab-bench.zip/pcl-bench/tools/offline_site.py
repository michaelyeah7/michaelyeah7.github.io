#!/usr/bin/env python3
"""Build a self-contained HTML reader from the website and finished release assets."""
import argparse
import base64
import json
from html import escape
from pathlib import Path


def safe_json(data):
    # Raw script text may not contain an HTML closing tag derived from a dataset.
    return json.dumps(data, ensure_ascii=True, separators=(",", ":")).replace("<", r"\u003c")


def encode(path):
    return base64.b64encode(path.read_bytes()).decode("ascii")


def build(site, paper, archive, output):
    page = (site / "index.html").read_text(encoding="utf-8")
    style = (site / "style.css").read_text(encoding="utf-8")
    app = (site / "app.js").read_text(encoding="utf-8")
    data = {
        "data/" + name: json.loads((site / "data" / name).read_text(encoding="utf-8"))
        for name in ("nodes.json", "catalog.json", "adaptation-map.json", "controls.json", "example-trajectory.json", "summit-replay.json")
    }
    icon = "data:image/svg+xml;base64," + encode(site / "mark.svg")
    page = page.replace('"mark.svg"', '"' + icon + '"')
    page = page.replace('<link rel="stylesheet" href="style.css">', "<style>" + style + "</style>")
    page = page.replace('<script defer src="app.js"></script>', "")
    binaries = {
        "paper/pcl-bench.pdf": ["application/pdf", encode(paper)],
        "downloads/pcl-bench.zip": ["application/zip", encode(archive)],
    }
    # Each attachment has one payload. Repeated links share the same object URL.
    for key in [*data, *binaries]:
        if f'href="{key}"' in page:
            attributes = f'data-file="{escape(key)}" download="{escape(Path(key).name)}"'
            page = page.replace(f'href="{key}"', attributes)
    loader = """
const embeddedRows=JSON.parse(document.getElementById('embedded-data').textContent);
const attachments=JSON.parse(document.getElementById('embedded-files').textContent);
const fileURLs=new Map();
for(const link of document.querySelectorAll('a[data-file]')){
  const key=link.dataset.file;
  if(!fileURLs.has(key)){
    let blob;
    if(Object.prototype.hasOwnProperty.call(attachments,key)){
      const [mime,encoded]=attachments[key];
      const bytes=Uint8Array.from(atob(encoded),c=>c.charCodeAt(0));
      blob=new Blob([bytes],{type:mime});
    }else{
      blob=new Blob([JSON.stringify(embeddedRows[key],null,2)],{type:'application/json'});
    }
    fileURLs.set(key,URL.createObjectURL(blob));
  }
  link.href=fileURLs.get(key);
}
"""
    scripts = (
        '<script type="application/json" id="embedded-data">' + safe_json(data) + "</script>"
        + '<script type="application/json" id="embedded-files">' + safe_json(binaries) + "</script>"
        + "<script>" + loader + "</script><script>" + app + "</script>"
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(page.replace("</body>", scripts + "</body>"), encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--site", type=Path, default=Path(__file__).resolve().parents[1] / "site")
    parser.add_argument("--paper", type=Path, required=True, help="Finished manuscript PDF")
    parser.add_argument("--archive", type=Path, required=True, help="Downloadable source ZIP")
    parser.add_argument("--output", type=Path, required=True, help="Standalone HTML path")
    args = parser.parse_args()
    build(args.site, args.paper, args.archive, args.output)
