#!/usr/bin/env python3
"""Build a static release and integrate it into the personal Pages repository."""
import argparse
import filecmp
from io import BytesIO
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
OWNER = 'michaelyeah7'
PROJECT = OWNER + '/pcl-bench'
PAGES = OWNER + '/' + OWNER + '.github.io'
DEFAULT_PAGES = Path('/Users/xieguo/Documents/identity/michaelyeah7.github.io')
BUTTON = '<a class="btn" href="pcl-bench/">Explore PCL-Bench</a>'
ANCHOR = '<a class="btn primary" href="#dream-brain">See DREAM Brain</a>'
LOCAL_MESSAGE = 'Add PCL-Bench project and homepage button'
REQUIRED = ('index.html', 'style.css', 'app.js', 'mark.svg', 'data/catalog.json',
            'data/nodes.json', 'data/adaptation-map.json', 'data/summit-replay.json', 'data/example-trajectory.json', 'data/controls.json', 'paper/pcl-bench.pdf')


def git(path, *args, binary=False):
    return subprocess.check_output(['git', '-C', str(path), *args], text=not binary)


def ensure_clean(path):
    if Path(git(path, 'rev-parse', '--show-toplevel').strip()).resolve() != path.resolve():
        raise ValueError(f'Expected a Git repository rooted at {path}')
    if git(path, 'status', '--porcelain', '--untracked-files=all').strip():
        raise ValueError(f'Working tree or index has changes. Preserve those changes before running: {path}')


def tree(path):
    if path.is_symlink():
        raise ValueError(f'Unexpected symlink: {path}')
    files = set()
    for file in path.rglob('*'):
        if file.is_symlink() or not (file.is_dir() or file.is_file()):
            raise ValueError(f'Unexpected special file: {file}')
        if file.is_file():
            files.add(file.relative_to(path))
    return files


def build(output):
    if output.exists() or output.is_symlink():
        raise ValueError(f'Output must be a new directory: {output}')
    archive = git(ROOT, 'archive', '--format=zip', 'HEAD:site', binary=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as td:
        stage = Path(td) / 'site'
        stage.mkdir()
        with ZipFile(BytesIO(archive)) as z:
            z.extractall(stage)
        for name in REQUIRED:
            if not (stage / name).is_file():
                raise ValueError(f'Release commit lacks site/{name}')
        downloads = stage / 'downloads'
        downloads.mkdir(exist_ok=True)
        subprocess.run(['git', '-C', str(ROOT), 'archive', '--format=zip', '--prefix=pcl-bench/',
                        '-o', str(downloads / 'pcl-bench.zip'), 'HEAD', '--', '.',
                        ':(exclude)site/downloads/pcl-bench.zip'], check=True)
        stage.rename(output)


def homepage_html(original):
    if original.count(BUTTON) == 1:
        return original
    if BUTTON in original or 'href="pcl-bench/"' in original or original.count(ANCHOR) != 1:
        raise ValueError('Homepage differs from expected markup. Review distribution/homepage-button.patch manually.')
    return original.replace(ANCHOR, ANCHOR + '\n        ' + BUTTON)


def prepare(pages):
    ensure_clean(pages)
    if not git(pages, 'symbolic-ref', '--short', 'HEAD').strip() in ('main', 'master'):
        raise ValueError('Use the personal site main or master branch.')
    path = pages / 'index.html'
    if path.is_symlink() or not path.is_file():
        raise ValueError('Expected a tracked regular index.html.')
    git(pages, 'ls-files', '--error-unmatch', '--', 'index.html')
    original = path.read_bytes()
    revised = homepage_html(original.decode('utf-8')).encode('utf-8')
    target = pages / 'pcl-bench'
    with tempfile.TemporaryDirectory(dir=pages.parent) as td:
        stage = Path(td) / 'release'
        build(stage)
        if target.is_symlink() or (target.exists() and not target.is_dir()):
            raise ValueError(f'Conflicting path: {target}')
        if target.exists():
            expected, actual = tree(stage), tree(target)
            if expected != actual or any(not filecmp.cmp(stage/f, target/f, shallow=False) for f in expected):
                raise ValueError('Existing pcl-bench/ differs. Review it before integrating this release.')
        if target.exists() and revised == original:
            tracked = git(pages, 'ls-files', '-z', '--', 'pcl-bench').split('\0')
            if set(tracked[:-1]) != {'pcl-bench/'+p.as_posix() for p in tree(stage)}:
                raise ValueError('Existing deployment contains ignored or untracked data; review before continuing.')
            return
        # Verify identity before changing tracked files.
        git(pages, 'var', 'GIT_AUTHOR_IDENT')
        git(pages, 'var', 'GIT_COMMITTER_IDENT')
        if not target.exists():
            stage.rename(target)
        if revised != original:
            path.write_bytes(revised)
        git(pages, 'add', '-f', '--', 'index.html', 'pcl-bench')
        git(pages, 'commit', '-m', LOCAL_MESSAGE)
    print(f'Prepared local Pages commit {git(pages, "rev-parse", "--short", "HEAD").strip()}.')


def check_origin(repo, name):
    allowed = {f'https://github.com/{name}', f'git@github.com:{name}', f'ssh://git@github.com/{name}'}
    for args in (('remote','get-url','--all','origin'), ('remote','get-url','--push','--all','origin')):
        urls = git(repo, *args).strip().splitlines()
        if len(urls) != 1 or urls[0].removesuffix('.git').rstrip('/') not in allowed:
            raise ValueError(f'Expected a single GitHub origin for {name}. Found {urls!r}.')


def publish(pages):
    ensure_clean(ROOT)
    ensure_clean(pages)
    if subprocess.check_output(['gh','api','user','--jq','.login'], text=True).strip().lower() != OWNER:
        raise ValueError(f'Authenticate gh as {OWNER} first.')
    check_origin(pages, PAGES)
    branch = git(pages, 'symbolic-ref', '--short', 'HEAD').strip()
    if branch not in ('main', 'master') or git(ROOT,'symbolic-ref','--short','HEAD').strip() != 'main':
        raise ValueError('Unexpected repository branch.')
    git(pages,'fetch','origin',f'refs/heads/{branch}')
    base, head = (git(pages,'rev-parse',r).strip() for r in ('FETCH_HEAD','HEAD'))
    if base != head:
        if (git(pages,'show','-s','--format=%P',head).strip() != base or
                git(pages,'show','-s','--format=%s',head).strip() != LOCAL_MESSAGE):
            raise ValueError('Personal branch has unpublished or divergent history; reconcile it before publishing.')
        changed = git(pages,'diff','--name-only','-z',base,head).split('\0')[:-1]
        if any(p != 'index.html' and not p.startswith('pcl-bench/') for p in changed):
            raise ValueError('Personal commit contains unrelated paths.')
        expected = homepage_html(git(pages,'show',f'{base}:index.html'))
        if expected != (pages / 'index.html').read_text(encoding='utf-8'):
            raise ValueError('Personal homepage contains additional edits.')
    if 'origin' not in git(ROOT,'remote').splitlines():
        # Inspect first. If creation fails (e.g. permissions), no existing remote can be overwritten.
        existing = subprocess.run(['gh','repo','view',PROJECT,'--json','nameWithOwner'],capture_output=True)
        if existing.returncode:
            subprocess.run(['gh','repo','create',PROJECT,'--public'],check=True)
        url = subprocess.check_output(['gh','repo','view',PROJECT,'--json','url','--jq','.url'],text=True).strip()
        if url != f'https://github.com/{PROJECT}':
            raise ValueError('Unexpected remote repository.')
        git(ROOT,'remote','add','origin',url+'.git')
    check_origin(ROOT, PROJECT)
    visibility = subprocess.check_output(
        ['gh','repo','view',PROJECT,'--json','visibility','--jq','.visibility'], text=True).strip()
    if visibility != 'PUBLIC':
        raise ValueError('The existing benchmark repository is not public; review its visibility before publishing.')
    # Normal pushes reject divergent history. An existing unrelated branch cannot be overwritten.
    advertised = git(ROOT,'ls-remote','--heads','origin').splitlines()
    if advertised:
        main = [line for line in advertised if line.endswith('\trefs/heads/main')]
        if len(main) != 1:
            raise ValueError('Existing GitHub repo contains branches but no main. No push performed.')
        git(ROOT,'fetch','origin','refs/heads/main')
        git(ROOT,'merge-base','--is-ancestor','FETCH_HEAD','HEAD')
    git(ROOT,'push','--set-upstream','origin','HEAD:refs/heads/main')
    if head != base:
        git(pages,'push','origin',f'HEAD:refs/heads/{branch}')
    print(f'Published repository source to https://github.com/{PROJECT}')
    print(f'Published Pages source on {branch}. Pages URL after deployment: https://{OWNER}.github.io/pcl-bench/')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('build').add_argument('output',type=Path)
    for name in ('prepare-personal', 'publish'):
        commands.add_parser(name).add_argument('--personal',type=Path,default=DEFAULT_PAGES)
    args = parser.parse_args()
    if args.command == 'build':
        build(args.output.resolve())
    elif args.command == 'prepare-personal':
        prepare(args.personal.resolve())
    else:
        publish(args.personal.resolve())


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, subprocess.CalledProcessError) as exc:
        sys.exit(f'PCL-Bench release stopped: {exc}')
