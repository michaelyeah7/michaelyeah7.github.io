#!/usr/bin/env python3
"""Rebuild the bibliography, compact citation display, node tables, and site catalog."""
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parents[1]
paper = root / "paper"
works = json.loads((root/"catalog/works.json").read_text())
programs = json.loads((root/"catalog/programs.json").read_text())
nodes = json.loads((root/"catalog/nodes.json").read_text())
def latex(s):
    return str(s).replace("&",r"\&").replace("$",r"\$").replace("%",r"\%").replace("#",r"\#").replace("_",r"\_").replace("’","'").replace("–","--").replace("ł",r"{\l}").replace("α",r"$\alpha$")

bib = []
for d in works + programs:
    # Include full citation metadata in the reusable bibliography. The PDF uses a short author list.
    def field(k,v): return "  "+k+" = {"+v+"},"
    f = [field("author",latex(d["bib_authors"])),field("title","{"+latex(d["title"])+"}"),field("year",str(d["year"])),field("howpublished",latex(d["venue"])),field("url",d["url"])]
    if d.get("doi"): f.append(field("doi",d["doi"]))
    bib.append("@misc{"+d["key"]+",\n"+"\n".join(f)+"\n}")
(paper/"references.bib").write_text("\n\n".join(bib)+"\n")
tex = (paper/"main.tex").read_text()+(paper/"catalog-notes.tex").read_text()+(paper/"replay-study.tex").read_text()
keys = list(dict.fromkeys(k.strip() for group in re.findall(r"\\cite\{([^}]+)\}",tex) for k in group.split(",")))
by_key = {d["key"]:d for d in works+programs}
if set(keys) != by_key.keys(): raise ValueError(f"Check missing or unused citation keys: {set(keys) ^ by_key.keys()}")
short = [r"\begin{thebibliography}{99}"]
for k in keys:
    d=by_key[k]
    short.append(r"\bibitem{"+k+r"} "+latex(d["authors"])+r" \href{"+d["url"]+"}{"+latex(d["title"])+"}. "+r"\textit{"+latex(d["venue"])+"}, "+str(d["year"]).rstrip(".")+".")
short.append(r"\end{thebibliography}")
(paper/"references-short.tex").write_text("\n".join(short)+"\n")
t=[]
for start in (0,10):
    if start: t += [r"\clearpage",r"\tagline{APPENDIX A \enspace/\enspace NODE TASK MAP, CONTINUED}"]
    t+= [r"\begin{center}\small\begin{tabularx}{\linewidth}{@{}p{.29\linewidth}Y@{}}\toprule",
         r"\textbf{NSF node and award} & \textbf{Candidate task for review}\\\midrule"]
    for d in nodes[start:start+10]:
        t+=[r"\textbf{"+latex(d["name"])+r"} \newline "+latex(d["institution"])+r" \href{"+d["source"]+r"}{\#"+d["award_id"]+"} & "+latex(d["task"])+r"\\[2pt]"]
    t+=[r"\bottomrule\end{tabularx}\end{center}"]
    if not start:t +=[r"\bhead{Example of a shared scoring concept} A lost reference can invalidate a biological plate or a chemical spectrum. What transfers is the requirement for traceable calibration. The quantity used for calibration, its acceptance interval and the action needed to recover must come from the respective laboratory."]
    else:t +=[r"\bhead{From award scope to data} For each row, record who can release a reference run, which fields are restricted, which physical units the instrument reports and how the local team adjudicates borderline cases. Until these questions are resolved, the row remains a proposed mapping."]
(paper/"nodes-table.tex").write_text("\n".join(t)+"\n")
(root/"site/data/catalog.json").write_text((root/"catalog/works.json").read_text())


# Keep the website views byte-aligned with the data used in the paper.
for src, dst in [("catalog/nodes.json", "nodes.json"),
                 ("catalog/adaptation-map.json", "adaptation-map.json"),
                 ("results/control-summary.json", "controls.json"),
                 ("adapters/summit_replay/results.json", "summit-replay.json"),
                 ("results/example-trajectory.json", "example-trajectory.json")]:
    (root / "site/data" / dst).write_bytes((root / src).read_bytes())

crosswalk = json.loads((root / "catalog/adaptation-map.json").read_text())
if [row["award_id"] for row in crosswalk] != [n["award_id"] for n in nodes]:
    raise ValueError("Crosswalk and roster identifiers disagree.")
for row in crosswalk:
    for ref in row["sources"]:
        canonical = by_key[ref["key"]]
        if ref["url"] != canonical["url"] or ref["title"] != canonical["title"]:
            raise ValueError(f'Mismatched source for {row["award_id"]}: {ref["key"]}')
