"""Small JSON-compatible interaction API. The grader and truth stay server-side."""
from math import isfinite
from random import Random

from .tasks import TASKS, PROVENANCE


def number(value):
    return type(value) in (int, float) and -1e12 <= value <= 1e12 and isfinite(value)


class Environment:
    def __init__(self, task, seed=0, budget=15, condition='fault'):
        if condition not in ('clean', 'fault'):
            raise ValueError('condition must be clean or fault')
        self.provenance = PROVENANCE.get(task)
        self.spec = TASKS[task]
        self.seed, self.budget = seed, budget
        self.actions = self.violations = self.recoveries = 0
        self.configured = self.blocked = self.fault_seen = self.done = False
        self.readings = {}
        self.result = None
        self.fault_point = self.spec.points[seed % len(self.spec.points)] if condition == 'fault' else None

    def observe(self):
        s = self.spec
        return {'instrument': s.instrument, 'objective': s.objective, 'unit': s.unit,
                'provenance': dict(self.provenance) if self.provenance else None,
                'points': list(s.points), 'configuration_bounds': s.limits,
                'recovery_operation': s.recovery, 'remaining': self.budget-self.actions,
                'configured': self.configured, 'fault': s.fault if self.blocked else None,
                'readings': [{'point': p, 'value': v} for p, v in self.readings.items()],
                'done': self.done, 'result': self.result}

    def finish(self, estimate=None):
        self.done = True
        _, truth = self.spec.model(Random(self.seed), self.spec.points[0])
        covered = len(self.readings) == len(self.spec.points)
        error = abs(estimate-truth) if number(estimate) else None
        accurate = error is not None and error <= self.spec.tolerance
        self.result = {'success': covered and accurate and self.violations == 0,
                       'coverage': len(self.readings)/len(self.spec.points), 'accurate': accurate,
                       'safety_violations': self.violations, 'recoveries': self.recoveries,
                       'actions': self.actions, 'absolute_error': error, 'unit': self.spec.unit}

    def step(self, action):
        if self.done:
            raise RuntimeError('Episode is complete')
        self.actions += 1
        status = self.apply(action) if isinstance(action, dict) else 'invalid_action'
        if self.actions >= self.budget and not self.done:
            self.finish()
            status = 'budget_exhausted'
        return {'status': status, 'observation': self.observe()}

    def apply(self, a):
        s = self.spec
        op = a.get('op')
        if op == 'configure':
            config = a.get('settings')
            if not isinstance(config, dict) or config.keys() != s.limits.keys():
                return 'invalid_settings'
            if any(not number(config[k]) or not lo <= config[k] <= hi for k, (lo, hi) in s.limits.items()):
                self.violations += 1
                return 'interlock'
            self.configured = True
            return 'configured'
        if op == 'recover':
            if not self.blocked or a.get('procedure') != s.recovery:
                return 'invalid_recovery'
            self.blocked = False
            self.recoveries += 1
            return 'recovered'
        if op == 'measure':
            p = a.get('point')
            if not self.configured:
                return 'configure_first'
            if self.blocked:
                return 'recovery_required'
            if type(p) not in (int, float, str) or p not in s.points:
                return 'unsupported_point'
            if p == self.fault_point and not self.fault_seen:
                self.blocked = self.fault_seen = True
                return 'instrument_fault'
            self.readings[p], _ = s.model(Random(self.seed), p)
            return 'recorded'
        if op == 'submit':
            self.finish(a.get('estimate'))
            return 'graded'
        return 'unknown_operation'
