"""Matched scripted controls, grouped only within commensurate task units."""
from itertools import groupby
from statistics import mean

from . import Environment
from .tasks import BUILTIN_TASKS
from .policies import decide

POLICIES = ('reference', 'no-recovery', 'shortcut-analysis')
CONDITIONS = ('clean', 'fault')


def run(task, seed, policy, trace=None, condition='fault'):
    if policy not in POLICIES:
        raise ValueError('Unknown control policy')
    env = Environment(task, seed, condition=condition)
    while not env.done:
        action = decide(env.observe(), policy)
        response = env.step(action)
        if trace is not None:
            trace.append({'action': action, **response})
    return {'task': task, 'seed': seed, 'policy': policy, 'condition': condition, **env.result}


def evaluate(n_seeds):
    return [run(task, seed, policy, condition=condition)
            for task in BUILTIN_TASKS for condition in CONDITIONS
            for policy in POLICIES for seed in range(n_seeds)]


def summarize(rows):
    out = []
    def key(row):
        return row['task'], row['condition'], row['policy']

    for (task, condition, policy), group in groupby(sorted(rows, key=key), key=key):
        g = list(group)
        errors = [r['absolute_error'] for r in g if r['absolute_error'] is not None]
        out.append({'task': task, 'condition': condition, 'policy': policy,
                    'episodes': len(g), 'successes': sum(r['success'] for r in g),
                    'mean_actions': mean(r['actions'] for r in g),
                    'safety_violations': sum(r['safety_violations'] for r in g),
                    'submitted_estimates': len(errors), 'unit': g[0]['unit'],
                    'mean_absolute_error': mean(errors) if errors else None})
    return out
