"""Deterministic scripted controls; no access to simulator internals."""
def decide(observation, policy='reference'):
    o = observation
    if not o['configured']:
        return {'op': 'configure', 'settings': {k: lo for k, (lo, hi) in o['configuration_bounds'].items()}}
    if o['fault'] and policy != 'no-recovery':
        return {'op': 'recover', 'procedure': o['recovery_operation']}
    values = {r['point']: r['value'] for r in o['readings']}
    for point in o['points']:
        if point not in values:
            return {'op': 'measure', 'point': point}
    if policy == 'shortcut-analysis':
        if o['instrument'] == 'plate_reader':
            estimate = 10 * values['sample'] / values['standard']
        elif o['instrument'] == 'spectrophotometer':
            estimate = min(values, key=values.get)
        elif o['instrument'] == 'source_meter':
            estimate = 1000 * values[1]
        else:
            raise ValueError('No shortcut is defined for this instrument')
    elif o['instrument'] == 'plate_reader':
        estimate = 10 * (values['sample'] - values['blank']) / (values['standard'] - values['blank'])
    elif o['instrument'] == 'spectrophotometer':
        estimate = max(values, key=values.get)
    elif o['instrument'] == 'source_meter':
        estimate = 1000 * (values[1] - values[-1]) / 2
    else:
        raise ValueError('No reference analysis is defined for this instrument')
    return {'op': 'submit', 'estimate': estimate}
