import argparse
import json
import sys

from . import Environment, TASKS
from .controls import run, evaluate, summarize, CONDITIONS


def main():
    parser = argparse.ArgumentParser(description='Run synthetic DREAM measurement environments')
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('list')
    ev = sub.add_parser('evaluate')
    ev.add_argument('--seeds', type=int, default=20)
    ev.add_argument('--summary', action='store_true')
    demo = sub.add_parser('trace')
    session = sub.add_parser('session')
    for item in (demo, session):
        item.add_argument('task', choices=TASKS)
        item.add_argument('--seed', type=int, default=0)
        item.add_argument('--condition', choices=CONDITIONS, default='fault')
    args = parser.parse_args()
    if args.command == 'list':
        print('\n'.join(TASKS))
    elif args.command == 'evaluate':
        if args.seeds < 1:
            parser.error('--seeds must be positive')
        rows = evaluate(args.seeds)
        print(json.dumps({'schema_version': 2, 'rows': summarize(rows) if args.summary else rows}, indent=2))
    elif args.command == 'trace':
        steps = []
        result = run(args.task, args.seed, 'reference', steps, args.condition)
        print(json.dumps({'result': result, 'steps': steps}, indent=2))
    elif args.command == 'session':
        env = Environment(args.task, args.seed, condition=args.condition)
        print(json.dumps({'status': 'ready', 'observation': env.observe()}), flush=True)
        for line in sys.stdin:
            try:
                action = json.loads(line)
            except ValueError:
                action = None
            print(json.dumps(env.step(action)), flush=True)
            if env.done:
                break


if __name__ == '__main__':
    main()
