"""Original, synthetic instrument models. Values illustrate workflows, not SOPs."""
from dataclasses import dataclass
from random import Random


@dataclass(frozen=True)
class Task:
    label: str
    instrument: str
    objective: str
    unit: str
    tolerance: float
    points: tuple
    limits: dict
    fault: str
    recovery: str
    model: object


def fluorescence(rng, point):
    blank = rng.randint(70, 140)
    concentration = rng.randint(20, 90) / 10
    gain = rng.randint(35, 70)
    samples = {'blank': 0, 'standard': 10, 'sample': concentration}
    return blank + gain * samples[point], concentration


def spectrum(rng, point):
    peak = rng.choice([460, 480, 500, 520])
    amplitude = rng.uniform(0.7, 0.95)
    return round(max(0.05, amplitude - 0.00012 * (point - peak) ** 2), 4), peak


def resistance(rng, point):
    ohms = rng.randrange(220, 1200, 10)
    offset = rng.uniform(-0.02, 0.02)
    return round(offset + ohms * point / 1000, 6), ohms


TASKS = {
    'fluorescence-calibration': Task('Fluorescence calibration', 'plate_reader',
        'Estimate protein concentration from blank, a 10 µM standard and unknown; assume linear fluorescence (RFU).',
        'µM', 0.05, ('blank', 'standard', 'sample'), {'gain': (1, 80)},
        'tray misalignment', 'reseat_tray', fluorescence),
    'absorbance-peak': Task('Absorbance peak', 'spectrophotometer',
        'Report the wavelength with greatest absorbance (AU) on the specified scan grid.',
        'nm', 0.5, (440, 460, 480, 500, 520, 540), {'exposure_ms': (1, 150)},
        'reference drift', 'reblank', spectrum),
    'iv-resistance': Task('I–V resistance', 'source_meter',
        'Infer sample resistance from voltage (V) versus signed applied current (mA), allowing a contact-voltage offset.',
        'Ω', 1.0, (-1, 0, 1), {'compliance_v': (1.5, 3)},
        'contact open', 'reconnect', resistance),
}

# This registry is intentionally process-local. Private adapters need not be published.
BUILTIN_TASKS = tuple(TASKS)
PROVENANCE = {}


def register_task(identifier, spec, *, node, source, permission, validation):
    """Register a Task with node, source, usage terms and a declared evidence stage."""
    if identifier in TASKS:
        raise ValueError(f'Task identifier is already registered: {identifier}')
    if not isinstance(spec, Task) or not callable(spec.model):
        raise ValueError('Provide a Task with a callable measurement model')
    if not spec.points or len(set(spec.points)) != len(spec.points):
        raise ValueError('Acquisition points must be nonempty and unique')
    if validation not in ('synthetic', 'reviewed-specification', 'trace-calibrated', 'prospectively-validated'):
        raise ValueError('Unknown validation stage')
    metadata = dict(node=node, source=source, permission=permission, validation=validation)
    if not all(isinstance(v, str) and v.strip() for v in (identifier, *metadata.values())):
        raise ValueError('Identifier and provenance fields must be nonempty strings')
    TASKS[identifier] = spec
    PROVENANCE[identifier] = metadata
    return identifier
