"""Budgeted fixed-table replay over checksummed Reizman–Suzuki/Summit records."""
import argparse
import csv
from collections import defaultdict
from hashlib import sha256
from io import StringIO
import json
from pathlib import Path
from random import Random
from statistics import mean
from urllib.request import urlopen

COMMIT = '1de682d05e97adcfb96cd8376e876cef2d6160d3'
BASE = f'https://raw.githubusercontent.com/sustainable-processes/summit/{COMMIT}/summit/benchmarks/data'
HASHES = (
    '346d976b89241662965f047b6725a9972941afb4c12105e82947cf9e2a27a450',
    '20f648b7e48a40059d4ba990161d0ad21cf255c45cdc90e6fa52a0e9b4150f3f',
    'cb57a2a8a4075ff312508e48673b3b4f22667b8fc609f7c60b57bb4f357a36b9',
    'fb2f2bd7eae04495f75a91996e309cc3f4f688a4fa02d7ef9e556246ce8bbf75',
)


def read_case(case, directory, fetch=False):
    if case not in (1, 2, 3, 4):
        raise ValueError('Expected a case number from 1 to 4.')
    path = Path(directory) / f'reizman_suzuki_case_{case}.csv'
    if not path.exists() and fetch:
        with urlopen(f'{BASE}/{path.name}', timeout=30) as response:
            raw = response.read()
    else:
        raw = path.read_bytes()
    if sha256(raw).hexdigest() != HASHES[case-1]:
        raise ValueError(f'Checksum mismatch: {path.name}')
    if fetch and not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    reader = csv.DictReader(StringIO(raw.decode('utf-8')))
    grouped = defaultdict(list)
    for row in reader:
        if row['NAME'] == 'TYPE':
            continue
        features = (row['catalyst'], float(row['t_res']), float(row['temperature']), float(row['catalyst_loading']))
        grouped[features].append(float(row['yld']))
    records = sum(len(v) for v in grouped.values())
    return {k: mean(v) for k, v in grouped.items()}, records


class Campaign:
    def __init__(self, measurements, budget=10):
        if not 1 <= budget <= len(measurements):
            raise ValueError('Budget must lie within finite pool.')
        self._truth = dict(measurements)
        self.candidates = sorted(measurements)
        self.history = {}
        self.budget = budget

    def observe(self):
        return {'columns': ['catalyst', 't_res', 'temperature', 'catalyst_loading'],
                'candidates': list(self.candidates), 'observations': list(self.history.items()),
                'remaining': self.budget-len(self.history)}

    def query(self, index):
        if len(self.history) >= self.budget:
            raise ValueError('Budget exhausted.')
        if type(index) is not int or not 0 <= index < len(self.candidates) or index in self.history:
            raise ValueError('Query must identify a new candidate in the pool.')
        self.history[index] = self._truth[self.candidates[index]]
        return self.history[index]

    def score(self):
        if len(self.history) != self.budget:
            raise ValueError('Finish the campaign before scoring.')
        best = max(self.history.values())
        return {'best_yield_pct': best, 'simple_regret_pp': max(self._truth.values())-best}


def baseline(measurements, seed, policy, budget=10):
    if policy not in ('random', 'local-greedy'):
        raise ValueError('Unknown policy.')
    env = Campaign(measurements, budget)
    pool = env.candidates
    order = list(range(len(pool)))
    Random(seed).shuffle(order)
    spans = [max(p[i] for p in pool)-min(p[i] for p in pool) for i in (1, 2, 3)]
    while len(env.history) < budget:
        unseen = [i for i in order if i not in env.history]
        if policy == 'random' or len(env.history) < 3:
            choice = unseen[0]
        else:
            best = pool[max(env.history, key=env.history.get)]
            def distance(i):
                condition = pool[i]
                return (condition[0] != best[0]) + sum(
                    abs(x-y)/width for x,y,width in zip(condition[1:], best[1:], spans) if width)
            choice = min(unseen, key=distance)
        env.query(choice)
    return env.score()


def evaluate(directory, fetch=False, seeds=20, budget=10):
    if seeds < 1:
        raise ValueError('Use at least one seed.')
    rows = []
    for case in range(1, 5):
        measurements, records = read_case(case, directory, fetch)
        for policy in ('random', 'local-greedy'):
            scores = [baseline(measurements, seed, policy, budget) for seed in range(seeds)]
            rows.append({'case': case, 'source_records': records, 'candidate_settings': len(measurements),
                         'policy': policy, 'campaigns': seeds, 'budget': budget,
                         'mean_best_yield_pct': mean(s['best_yield_pct'] for s in scores),
                         'mean_simple_regret_pp': mean(s['simple_regret_pp'] for s in scores)})
    return {'source_commit': COMMIT, 'sha256_by_case': HASHES, 'rows': rows}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path, required=True)
    parser.add_argument('--fetch', action='store_true', help='Download absent CSVs from the pinned upstream source.')
    parser.add_argument('--seeds', type=int, default=20)
    parser.add_argument('--budget', type=int, default=10)
    args = parser.parse_args()
    print(json.dumps(evaluate(args.data_dir, args.fetch, args.seeds, args.budget), indent=2))
