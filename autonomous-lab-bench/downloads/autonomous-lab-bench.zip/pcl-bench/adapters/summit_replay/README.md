# Four published Suzuki–Miyaura campaigns

This independent replay task uses the experimental observations of Reizman, Wang, Buchwald and Jensen, as distributed in Summit. Four case studies use different reacting substrates. The goal here is to discover a high-yielding **observed** setting in a ten-query campaign. Choices are limited to a fixed pool of catalyst labels, residence times (s), temperatures (°C) and catalyst loadings (mol%). Querying a condition reveals its historical product yield (%). Turnover number is outside this scoring contract. No learned surrogate, physical simulator or prospective validation enters the score.

## Run

From the research checkout or extracted source ZIP, choose a cache directory outside the repository. Python 3.9+ is sufficient.

```bash
python3 adapters/summit_replay/replay.py --fetch --data-dir "$HOME/.cache/pcl-bench/summit" > replay-result.json
```

The explicit fetch obtains four CSVs from an immutable upstream commit and verifies each SHA-256 before use. Repeat without `--fetch` to work offline. An existing Git checkout of the upstream revision can be used directly by pointing `--data-dir` at `summit/benchmarks/data`. Byte-level checks include the original line endings. Public release files contain the adapter, source identifiers and aggregate results. The upstream CSVs remain with their provider.

## Run an external policy

```python
from adapters.summit_replay.replay import Campaign, read_case

measured, _ = read_case(1, '/path/to/verified/cache')
env = Campaign(measured, budget=10)
while (observation := env.observe())['remaining']:
    # Replace this index rule with an agent that sees observation only.
    sampled = {i for i, _ in observation['observations']}
    idx = next(i for i in range(len(observation['candidates'])) if i not in sampled)
    measured_yield = env.query(idx)
print(env.score())
```

In a blinded evaluation, keep the host process, upstream files and `measured` private. Expose only the acquisition observations and query interface to the policy. Completion exposes simple regret in percentage points. Identical settings, matched on the four recorded inputs after numeric parsing, are merged by averaging measured yields. That choice smooths replicate noise. Cases have 96, 96, 96 and 97 source rows and 81, 80, 93 and 95 candidate settings respectively.

## Matched controls

For each case, both policies query the same three random candidates at the start of every run. Candidate IDs use sorted input features; a seeded shuffle sets the common initial order and tie-breaker. Uniform random continues without replacement. Local-greedy queries the closest unobserved setting to the incumbent with the highest revealed yield. Distance adds one for a different catalyst, plus the three absolute numeric differences divided by their per-case pool ranges. Both score after ten distinct queries. Terminal simple regret is the best mean yield among all recorded settings minus the best mean yield revealed within budget. The optimum is defined only within each measured pool.

| Case | Source rows | Unique settings | Random mean regret (pp) | Local-greedy mean regret (pp) |
| --- | ---: | ---: | ---: | ---: |
| 1 | 96 | 81 | 13.98 | 10.08 |
| 2 | 96 | 80 | 14.43 | 10.85 |
| 3 | 96 | 93 | 5.58 | 3.63 |
| 4 | 97 | 95 | 5.60 | 5.62 |
| Equal-weight case mean | | | 9.90 | 7.55 |

The [aggregate results](results.json) use seeds 0–19, including 160 campaigns and 1,600 retrospective queries. Historical experimental selection limits the available candidate pool. Random seeds replicate the policy comparison on fixed data. They are not independent laboratories, reactions or wet-lab trials.

## Source records

- B. J. Reizman, Y.-M. Wang, S. L. Buchwald and K. F. Jensen (2016). *Suzuki–Miyaura cross-coupling optimization enabled by automated feedback*. Reaction Chemistry & Engineering 1, 658–666. [Primary study](https://doi.org/10.1039/C6RE00153J)
- K. C. Felton, J. G. Rittig and A. A. Lapkin (2021). *Summit: Benchmarking Machine Learning Methods for Reaction Optimisation*. Chemistry–Methods. [Benchmark paper](https://doi.org/10.1002/cmtd.202000051)
- The implementation pins revision `1de682d05e97adcfb96cd8376e876cef2d6160d3`. [Upstream data and provenance](https://github.com/sustainable-processes/summit/tree/1de682d05e97adcfb96cd8376e876cef2d6160d3/summit/benchmarks/data) · [Upstream domain definitions](https://github.com/sustainable-processes/summit/blob/1de682d05e97adcfb96cd8376e876cef2d6160d3/summit/benchmarks/experimental_emulator.py)
