"""Regenerate the vector figures from the specification and released results."""
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.lines import Line2D
p = Path(__file__).resolve().parent
out = p / "figures"
out.mkdir(exist_ok=True)
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"svg.fonttype":"none","pdf.fonttype":42})
ink, muted, teal, violet, clay = "#172b36","#47606b","#087f78","#51439a","#a34322"
def save(fig,name):
    for ext in ("pdf","svg"): fig.savefig(out / f"{name}.{ext}",bbox_inches="tight",pad_inches=0.05)
    plt.close(fig)
def text(ax,x,y,s,**kw): ax.text(x,y,s,va="center",**kw)
def arrow(ax,a,b): ax.annotate("",xy=b,xytext=a,arrowprops={"arrowstyle":"->","color":muted,"lw":1.25})
fig,ax=plt.subplots(figsize=(8.1,2.5));ax.set(xlim=(0,10),ylim=(0,3.7));ax.axis("off")
for x,y,w,h,title,desc,k,bg in [
 (0.02,1.2,2.12,1.75,"Node evidence","SOP revision\nInstrument limits\nReference run",teal,"#e6f3ef"),
 (2.60,1.2,2.22,1.75,"Task contract","Allowed operations\nMeasurement model\nAcceptance criteria",violet,"#eeeaf7"),
 (5.29,1.2,2.22,1.75,"Instrument trial","Configure and read\nObserve faults\nRecover and retry",ink,"#eaf0f4"),
 (7.95,1.2,2.02,1.75,"Graded evidence","Action trace\nQualified readings\nEndpoint and cost",clay,"#f9eee8")]:
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.015,rounding_size=0.10",edgecolor="none",facecolor=bg))
    text(ax,x+.12,y+h-.35,title,weight="bold",color=k,fontsize=10.3)
    text(ax,x+.12,y+.64,desc,color=ink,fontsize=8.6,linespacing=1.5)
for a,b in [(2.16,2.57),(4.84,5.25),(7.54,7.91)]:arrow(ax,(a,2.11),(b,2.11))
ax.plot([8.94,8.94,3.70,3.70],[1.15,.67,.67,1.02],color=muted,lw=1);arrow(ax,(3.70,.90),(3.70,1.18))
text(ax,6.35,.29,"Node review compares traces with independent records",ha="center",color=muted,fontsize=8.7)
save(fig,"contract")
trace=json.loads((p.parent/'results/example-trajectory.json').read_text())["steps"]
fig,ax=plt.subplots(figsize=(8.3,2.45));ax.axis("off");n=len(trace);ax.set(xlim=(-.52,n-.5),ylim=(-1,1.9))
ax.axhline(.49,xmin=.07,xmax=.93,color="#c0cdd2",zorder=1,lw=2)
for i,t in enumerate(trace):
    a=t["action"];st=t["status"]
    op=a["op"];label={"configure":"Set gain","measure":str(a.get("point","")).capitalize(),"recover":"Reseat tray","submit":"Submit"}[op]
    c=clay if st=="instrument_fault" else violet if st=="recovered" else teal
    ax.scatter(i,.49,s=190,c=c,zorder=3);text(ax,i,.49,str(i+1),ha="center",weight="bold",color="white",fontsize=8.5,zorder=4)
    text(ax,i,1.1,label,ha="center",weight="bold",color=ink,fontsize=9)
    if st=="recorded": val=t["observation"]["readings"][-1]["value"];sub=f"{val:g} RFU"
    else: sub={"configured":"within range","instrument_fault":"tray fault","recovered":"cleared","graded":f"{a.get('estimate',0):.1f} µM"}[st]
    text(ax,i,-.12,sub,ha="center",color=c,fontsize=8.8)
text(ax,0,-.68,"The failed read returns no intensity. The retry supplies the standard used in the estimate.",fontsize=8.5,color=muted)
save(fig,"trajectory")
rows=json.loads((p.parent/'results/control-summary.json').read_text())['rows']
pols=['reference','no-recovery','shortcut-analysis']; colors=[teal,violet,clay]
fig,(left,right)=plt.subplots(1,2,figsize=(8.3,2.85),gridspec_kw={'width_ratios':[1.03,1]})
for idx,(policy,color) in enumerate(zip(pols,colors)):
    group=[r for r in rows if r['policy']==policy]
    for j,cond in enumerate(['clean','fault']):
        subset=[r for r in group if r['condition']==cond]; succ=sum(r['successes'] for r in subset);total=sum(r['episodes'] for r in subset)
        y=2-idx+(0.14 if j==0 else -0.14)
        left.barh(y,succ/total,height=.21,color=color,alpha=.44 if j==0 else 1);left.text(succ/total+.025,y,f'{succ}/{total}',va='center',fontsize=8,color=ink)
left.set(yticks=[2,1,0],yticklabels=['Reference','No recovery','Analysis shortcut'],xlim=(0,1.32),xticks=[0,.5,1],xticklabels=['0%','50%','100%'],ylim=(-.5,2.56))
left.set_title('A   Task success',loc='left',weight='bold',color=ink);left.set_xlabel('Light = clean     Dark = injected fault',fontsize=8,color=muted)
names=['fluorescence-calibration','absorbance-peak','iv-resistance']
for i,t in enumerate(names):
    for j,cond in enumerate(['clean','fault']):
        n=next(r['mean_actions'] for r in rows if r['policy']=='reference' and r['task']==t and r['condition']==cond)
        right.barh(2-i+(0.14 if j==0 else -.14),n,height=.21,color=teal,alpha=.44 if j==0 else 1)
        right.text(n+.25,2-i+(0.14 if j==0 else -.14),str(n),va='center',fontsize=8)
right.axvline(15,ls='--',color=clay,lw=1);right.set(yticks=[2,1,0],yticklabels=['Fluorescence','Absorbance','I–V sweep'],xlim=(0,16),xticks=[0,5,10,15],ylim=(-.5,2.56))
right.set_title('B   Reference policy cost',loc='left',weight='bold',color=ink);right.set_xlabel('Actions per episode   /   budget = 15',fontsize=8,color=muted)
for ax in (left,right):
    ax.spines[['top','right','left']].set_visible(False);ax.tick_params(axis='both',length=0,labelsize=8);ax.spines['bottom'].set_color('#c0cdd2')
fig.subplots_adjust(wspace=.48,left=.16,right=.97,bottom=.2,top=.86)
save(fig,"controls")

replay=json.loads((p.parent/'adapters/summit_replay/results.json').read_text())['rows']
fig,ax=plt.subplots(figsize=(7.8,2.62))
for i in range(4):
    pair={r['policy']:r['mean_simple_regret_pp'] for r in replay if r['case']==i+1}
    y=3-i
    low,high=sorted(pair.values())
    ax.plot([low,high],[y,y],color='#b2bbbf',lw=2.7,zorder=1)
    for pol,c,marker in [('random',violet,'o'),('local-greedy',teal,'D')]:
        v=pair[pol]; ax.scatter(v,y,s=45,c=c,marker=marker,edgecolor='white',linewidth=.5,zorder=2)
        ax.text(v,y+(.18 if pol=='random' else -.19),f'{v:.2f}',va='center',ha='center',color=c,fontsize=8)
ax.set(yticks=[3,2,1,0],yticklabels=['Case 1','Case 2','Case 3','Case 4'],ylim=(-.44,3.48),xlim=(0,16),xticks=[0,4,8,12,16])
ax.grid(axis='x',color='#e5e9eb');ax.set_axisbelow(True)
ax.spines[['left','top','right']].set_visible(False);ax.spines['bottom'].set_color('#c0cdd2');ax.tick_params(axis='both',length=0)
ax.set_xlabel('Terminal simple regret (yield percentage points; lower is better)',fontsize=8.5,color=muted)
legend=[Line2D([],[],marker=m,ls='',color=c,label=n,markersize=6) for n,c,m in [('Uniform random',violet,'o'),('Local greedy',teal,'D')]]
ax.legend(handles=legend,frameon=False,ncol=2,loc='lower right',bbox_to_anchor=(1,1.01),fontsize=8)
fig.subplots_adjust(top=.79,bottom=.2,left=.12,right=.97)
save(fig,"replay")
