# Manuscript and figures

Open the rendered manuscript at [pcl-bench.pdf](pcl-bench.pdf). Edit the manuscript in main.tex. The project byline is provisional and the manuscript is a working research draft. The PDF links citation titles directly to their primary sources and links all 20 awards independently. Full available author lists are in references.bib.

From the project root, rebuild the catalog-derived tables, bibliography and figures, then compile with a recent TeX Live installation. Figure generation needs Python and matplotlib only. The benchmark itself uses the Python standard library.

```bash
python3 tools/build_catalog.py
python3 paper/figures.py
cd paper
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
cp main.pdf pcl-bench.pdf
mkdir -p ../site/paper
cp pcl-bench.pdf ../site/paper/pcl-bench.pdf
```

The two results figures read the released aggregate JSON for the instrument controls and the measured-yield replay. The trajectory figure reads an actual reference trace. Vector originals are available as PDF and SVG. The benchmark architecture diagram represents a proposed cross-node review process.
