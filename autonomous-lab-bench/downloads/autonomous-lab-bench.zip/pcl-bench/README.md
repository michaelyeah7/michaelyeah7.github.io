# PCL-Bench · A Digital Twin for Every PCL Node

A research starter for evaluating agents that use laboratory instruments. Run a complete interaction locally with Python 3.9+ and the standard library. The prototype contains three original synthetic characterization environments. The wider research plan targets the 20-team NSF PCL network. No team endorsement, real instrument integration or validated partner environment is implied by these fixtures.

## Explore the release

| Resource | What you can use |
| --- | --- |
| [Illustrated paper](paper/pcl-bench.pdf) and [LaTeX source](paper/main.tex) | Methods, four scientific figures, paired controls and clickable primary citations. |
| [Research catalog](catalog/works.json) and [BibTeX](paper/references.bib) | Searchable prior work with an adaptation for every entry. |
| [20-node crosswalk](docs/NODE_CROSSWALK.md) and [machine-readable mappings](catalog/adaptation-map.json) | Individual NSF awards, upstream methods, proposed experiments, requested data and held-out diagnostics. |
| [Static project website](site/) | Animated node atlas, fault-recovery walkthrough, evaluation results and searchable sources. |
| [Mac integration](distribution/README.md) | Install the project and integrate the webpage with the existing personal GitHub Pages site. |
| [Historical reaction replay](adapters/summit_replay/) | A working adapter for four published Suzuki–Miyaura cases, with 160 measured-outcome campaigns. |
| [External agent example](examples/json_agent.py) | Drive a task through newline-delimited JSON without an API key. |

## Try a task

Run from the repository root. No credentials, packages or model endpoints are required for the scripted controls.

```bash
python -m pclbench list
python examples/json_agent.py
python -m pclbench trace fluorescence-calibration --seed 7
python -m pclbench evaluate --seeds 20 > my-controls.json
python -m pclbench evaluate --summary > my-summary.json
python -m examples.node_adapter
python -m unittest discover -s tests -v
```

| Environment | Evidence required | Report | Recovery operation |
| --- | --- | --- | --- |
| `fluorescence-calibration` | Blank, 10 µM standard and unknown (RFU) | Protein concentration (µM) | `reseat_tray` |
| `absorbance-peak` | Six absorbance readings spanning 440–540 nm | Discrete peak wavelength (nm) | `reblank` |
| `iv-resistance` | Voltage at −1, 0 and +1 mA | Resistance (Ω) | `reconnect` |

## Connect an agent

Use Python's `Environment` or launch `python -m pclbench session iv-resistance --seed 3` in a subprocess. The command writes a ready observation, reads one JSON action per line, writes one JSON response per action and exits when `observation.done` is true. Instructions, legal acquisition points, setting ranges, recovery procedure, readings and remaining budget are visible to the policy. The grader's truth is kept out of observations. For independent evaluation, run the simulator outside the agent process and do not expose source, seeds or traces to the agent. The JSON protocol is a portability interface, not an isolation boundary.

```python
from pclbench import Environment
from pclbench.policies import decide  # replace with your tool-calling agent

env = Environment('absorbance-peak', seed=3)
observation = env.observe()
while not observation['done']:
    action = decide(observation)
    result = env.step(action)
    observation = result['observation']
print(observation['result'])
```

| Action example | Effect |
| --- | --- |
| `{"op":"configure","settings":{"compliance_v":2}}` | Configure the source meter within its synthetic operating limits. |
| `{"op":"measure","point":-1}` | Acquire one voltage at −1 mA, or receive a fault. |
| `{"op":"recover","procedure":"reconnect"}` | Clear an open contact after the instrument reports it. |
| `{"op":"submit","estimate":540}` | End the episode with a resistance estimate in Ω. |

Every attempted action costs one of 15 steps. Under the default `fault` condition the first attempted acquisition at a seed-selected point triggers a fault. Use `--condition clean` for a paired fault-free session. Recovery and retry are necessary. Re-reading a point does not increase coverage. An out-of-bounds numeric instrument setting triggers an interlock, increments the violation count, and disqualifies the episode. Malformed requests consume budget. Success requires all prescribed readings, a submitted finite estimate within absolute tolerance (0.05 µM, 0.5 nm or 1 Ω), and zero interlock violations. A timeout ends the episode without an estimate. The returned result also records coverage, numerical accuracy, recoveries and action count.

## Reproduce the controls

[`results/scripted-controls.json`](results/scripted-controls.json) contains 360 episodes. Each of three scripted policies operates on the same 60 task–seed pairs under both clean and fault-injected conditions. The reference acquires every point, applies the documented recovery when needed and computes the endpoint. The no-recovery ablation only removes the recovery branch. The shortcut-analysis control instead uses the uncorrected fluorescence ratio, selects a trough in the absorbance scan, or estimates resistance from the positive current only. It retains the reference policy’s acquisition and recovery steps.

| Policy | Clean, successes / 60 | Fault, successes / 60 | Mean actions, clean / fault |
| --- | ---: | ---: | ---: |
| Reference | 60 | 60 | 6 / 8 |
| No recovery | 60 | 0 | 6 / 15 |
| Shortcut analysis | 0 | 0 | 6 / 8 |

The shortcut completed all required acquisitions. Its mean absolute errors were 0.592 µM, 70 nm and 10.221 Ω; identical values under both conditions reflect paired, noiseless signals. All 360 scripted episodes recorded zero safety violations. The dedicated interlock test exercises unsafe requests and checks that the eventual estimate cannot earn success. [Grouped results](results/control-summary.json) report errors only for episodes with a submitted estimate. The blocked no-recovery runs have no numerical-error value. These controls characterize simulator behavior; model and hardware evaluations remain open.

A full [example trajectory](results/example-trajectory.json) includes per-step actions, statuses and observations. It can be replayed without a model service. To reproduce exact output, use the same Python version and compare the parsed JSON to the published file.

## Add a node workflow

Use the public `register_task` API in this [28-line runnable example](examples/node_adapter.py) and follow the [adapter guide](docs/ADAPTERS.md). The present simulator exposes simplified configuration bounds, one injected fault, one acquisition per point, one numerical endpoint and noiseless synthetic data. Configuration is a gate to acquisition only. It does not change the synthetic transfer function. An actual node adapter should supply a trace-calibrated measurement model, local capability limits, explicit data-use permissions, expert review and independently versioned held-out cases.

## License

The MIT license covers the original starter software. Upstream papers, linked resources, trademarks, partner records and future third-party adapters retain their own terms. The current package includes no external task corpora.
