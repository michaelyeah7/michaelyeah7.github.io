# From prior work to 20 proposed node tasks

Each entry starts with a public NSF award and a candidate task for that node’s review. The proposed measurements, fault modes and data requests need confirmation by the instrument owner. A source link identifies the method being adapted. Every benchmark item, grading tolerance and permission to distribute data needs its own record.

[Machine-readable crosswalk](../catalog/adaptation-map.json) · [Award roster and candidate rubrics](../catalog/nodes.json) · [Implement an adapter](ADAPTERS.md)

| Node | Proposed task |
| --- | --- |
| [DREAM](#award-2607522) | Estimate a biosensor response curve after excluding a plate with failed controls. |
| [CLAIRE](#award-2607506) | Compare cell-free reporter designs across plates with different reader gains. |
| [CRAB Lab](#award-2607564) | Detect drift in a bioprocess sensor before changing a simulated feed schedule. |
| [AI-BIOME](#award-2607601) | Choose a repeat characterization that distinguishes two candidate assemblies. |
| [AI Science Foundry](#award-2607594) | Route an assay to a compatible instrument when its scheduled reader is unavailable. |
| [SPEED](#award-2607495) | Pick the next solution-phase experiment after a reference spectrum drifts. |
| [COAST](#award-2607521) | Compare viscoelastic curves for candidate soft materials after a geometry change. |
| [ELECTRA](#award-2607629) | Select a follow-up diffraction measurement from incomplete or degraded patterns. |
| [GEMSTONE](#award-2607573) | Bind an abstract transfer and readout protocol to two different mock device APIs. |
| [Reaction Discovery](#award-2607628) | Rank candidate conditions after detecting a missing internal standard. |
| [PoLARIS](#award-2607613) | Choose the next polymer composition after a replicated property disagrees. |
| [PCL-AIMMPF](#award-2607581) | Compare manufacturing settings using matched reference coupons. |
| [AIMD-NET](#award-2607526) | Route alloy samples for follow-up tests after uncertainty in a property estimate. |
| [ATHENA](#award-2607469) | Reacquire a scan region after simulated tip drift degrades an image. |
| [ICoN-PCL](#award-2607533) | Select a follow-up probe to distinguish two candidate material states. |
| [Self-Driving Nanofab](#award-2607580) | Reschedule a fabrication and metrology queue after a tool becomes unavailable. |
| [LATTICE](#award-2607536) | Identify a thickness gradient from spatially sparse metrology and choose new sites. |
| [Electronics Prototyping](#award-2607577) | Estimate component resistance from a simulated sweep with a bad contact. |
| [READINESS](#award-2607553) | Choose a follow-up characterization after a candidate film misses its target. |
| [AURORA](#award-2607535) | Decide whether a stacked flake is aligned well enough for transport measurement. |

<a id="award-2607522"></a>

## DREAM · Protein engineering

Northwestern University · [NSF award 2607522](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607522)

**Candidate task.** Estimate a biosensor response curve after excluding a plate with failed controls.

- Hide the later experimental decision when presenting the earlier evidence. [Gamow LabBench](https://gamowlabs.com/labbench-benchmarking-ai-wet-lab-decisions)
- Group related protein designs when separating development and evaluation data. [FLIP2](https://proceedings.mlr.press/v306/didi26a.html)
- Charge each proposed batch against a finite experimental budget. [Ginkgo/OpenAI CFPS](https://doi.org/10.64898/2026.02.05.703998)

**Node adaptation.** Replace fitness prediction with blinded concentration–response fitting. Give the agent plate controls, an allowable concentration range and the option to repeat a plate.

**Minimum evidence request.** One shareable plate map, raw readings from a valid plate and a control-failing plate, concentrations and units, and a held-back fit or expert adjudication. Ask which readout and response model the scientist trusts.

**Held-out check.** Assign whole plates and all replicates of one variant family to one split. Reject confidence in an EC50 when the accepted concentrations do not bracket the response midpoint.

<a id="award-2607506"></a>

## CLAIRE · Biological design

Boston University · [NSF award 2607506](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607506)

**Candidate task.** Compare cell-free reporter designs across plates with different reader gains.

- Retain a cell-free expression run with a measured output. [Ginkgo/OpenAI CFPS](https://doi.org/10.64898/2026.02.05.703998)
- Compare derived numerical artifacts to independently generated reference artifacts. [BixBench3](https://arxiv.org/abs/2608.25286)

**Node adaptation.** Vary reader gain and saturation while preserving common reference wells. Ask for comparable reporter rankings and an explicit flag for comparisons outside the calibrated range.

**Minimum evidence request.** Paired exports from two gain settings on a common reference series, a plate map, and the operator-approved linear range or saturation flag.

**Held-out check.** Hide one complete plate or reader session. Include a design whose apparent rank changes under naive pooling, and verify the corrected order only among measurable designs.

<a id="award-2607564"></a>

## CRAB Lab · Biomanufacturing

University of Maryland · [NSF award 2607564](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607564)

**Candidate task.** Detect drift in a bioprocess sensor before changing a simulated feed schedule.

- Let interventions generate successive process observations. [SciGym](https://proceedings.neurips.cc/paper_files/paper/2025/hash/a23760ba51036d530a2656c3835f826c-Abstract-Datasets_and_Benchmarks_Track.html)
- Require feedback-driven decisions during an acquisition. [LabOSBench](https://arxiv.org/abs/2606.16802)

**Node adaptation.** Add a drifting sensor and an independent offline check to a node-selected bioprocess variable. Permit a calibration or confirmatory sample before changing a feed setting.

**Minimum evidence request.** An annotated time segment around a measurement discrepancy, an aligned independent assay, sampling delays, and the approved range for a simulated adjustment.

**Held-out check.** Hold out an entire run. Pair a sensor-offset case with a true process excursion and compare detection delay and unnecessary feed interventions.

<a id="award-2607601"></a>

## AI-BIOME · Bioinspired materials

City College of New York · [NSF award 2607601](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607601)

**Candidate task.** Choose a repeat characterization that distinguishes two candidate assemblies.

- Make the next measurement discriminate competing hypotheses. [DiscoveryWorld](https://papers.nips.cc/paper_files/paper/2024/hash/13836f251823945316ae067350a5c366-Abstract-Datasets_and_Benchmarks_Track.html)
- Charge noisy measurements to a common acquisition budget. [Olympus](https://doi.org/10.1088/2632-2153/abedc8)

**Node adaptation.** Define two node-selected assembly states that look similar in the first measurement. Price a second characterization and include the option to report unresolved structure.

**Minimum evidence request.** A matched pair of assembly readouts, an independent state label, one repeat measurement and the cost or time for each permitted test.

**Held-out check.** Keep each specimen and its repeats together. Score held-out state discrimination at equal cost and check whether an uninformative repeat was recognized as such.

<a id="award-2607594"></a>

## AI Science Foundry · Multi-domain automation

Carnegie Mellon University · [NSF award 2607594](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607594)

**Candidate task.** Route an assay to a compatible instrument when its scheduled reader is unavailable.

- Bind a device-independent operation graph to available modules. [Programmable chemical synthesis](https://doi.org/10.1126/science.abc2986)
- Keep the same high-level liquid-handling intent across backend configurations. [PyLabRobot](https://doi.org/10.1016/j.device.2023.100111)
- Validate the device-bound script before scheduling execution. [iCloudBiofoundry](https://doi.org/10.64898/2026.09.30.750244)

**Node adaptation.** Disable the scheduled reader mid-workflow. Supply an alternative with different plate compatibility, readout channels or queue times, while preserving sample identity.

**Minimum evidence request.** One approved workflow, two sanitized capability manifests, a queue or outage event, compatible labware definitions and a sample-handoff trace.

**Held-out check.** Hold out a device pairing. Check capability and identity invariants plus elapsed time, including a case where deferral is the only valid action.

<a id="award-2607495"></a>

## SPEED · Solution chemistry

NC State University · [NSF award 2607495](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607495)

**Candidate task.** Pick the next solution-phase experiment after a reference spectrum drifts.

- Compare reaction condition decisions under an explicit optimization budget. [Summit](https://doi.org/10.1002/cmtd.202000051)
- Propagate material state through sequential chemical operations. [ChemGymRL](https://doi.org/10.1039/D3DD00183K)

**Node adaptation.** Insert an optical reference and a drifting wavelength or intensity response before the agent selects the next solution-phase condition. Allow a reblank or repeat only when justified.

**Minimum evidence request.** Reference and sample spectra with units, an operator-labelled drift example, allowable solution conditions and measurement costs.

**Held-out check.** Hold out a solution preparation day. Distinguish reference drift from a true sample peak shift using a blinded standard acquired in the same session.

<a id="award-2607521"></a>

## COAST · Soft materials

UC Santa Barbara · [NSF award 2607521](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607521)

**Candidate task.** Compare viscoelastic curves for candidate soft materials after a geometry change.

- Validate intermediate analysis artifacts as well as the final reported quantity. [BixBench3](https://arxiv.org/abs/2608.25286)
- Compare decisions on noisy property measurements under a fixed budget. [Olympus](https://doi.org/10.1088/2632-2153/abedc8)

**Node adaptation.** Replace generic property labels with the node’s selected rheological quantity. Give raw or processed curves with their actual geometry metadata and operating envelope.

**Minimum evidence request.** A matched soft-material sample measured with two geometries, radius or gap metadata as applicable, the controlled variable, a valid working range and an independent reduction.

**Held-out check.** Hold out one polymer batch or specimen across both geometries. Compare its corrected property ranks inside the valid range and require a flag when cross-geometry comparison is unsupported.

<a id="award-2607629"></a>

## ELECTRA · Electron diffraction

Caltech · [NSF award 2607629](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607629)

**Candidate task.** Select a follow-up diffraction measurement from incomplete or degraded patterns.

- Use independent physical plausibility checks after interpreting diffraction evidence. [XRDBench](https://arxiv.org/abs/2609.00070)
- Meter measurements and expose state-dependent settings on a virtual instrument. [q-devBench](https://arxiv.org/abs/2610.41717)

**Node adaptation.** Translate the diffraction decision logic to electron diffraction with tilt, dose and reciprocal-space coverage. Obtain electron-specific response and damage models from the node.

**Minimum evidence request.** An indexed tilt series with acquisition metadata, an exposure budget, a coverage mask, and an example of specimen damage or incomplete sampling.

**Held-out check.** Hold out all tilts from a specimen. Credit additional reciprocal-space coverage within budget and compare the structural call with an independent reconstruction.

<a id="award-2607573"></a>

## GEMSTONE · Interoperable protocols

Stanford University · [NSF award 2607573](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607573)

**Candidate task.** Bind an abstract transfer and readout protocol to two different mock device APIs.

- Compile an abstract procedure against the device graph. [Programmable chemical synthesis](https://doi.org/10.1126/science.abc2986)
- Expose transferable high-level operations with backend-specific bindings. [PyLabRobot](https://doi.org/10.1016/j.device.2023.100111)
- Separate code validity from validation of the executed workflow. [ProtoPilot](https://arxiv.org/abs/2606.31763)

**Node adaptation.** Run the same transfer-and-readout intent on two mock APIs with different units, resource identifiers or error codes. Publish the semantic postconditions for both.

**Minimum evidence request.** One protocol intent, two exportable command schemas and example requests, verified unit conversions, and a short operator-accepted trace for each backend.

**Held-out check.** Withhold one API dialect until evaluation. Give it a fresh manifest and compare sample identity, transferred quantity, final readout units and provenance after execution.

<a id="award-2607628"></a>

## Reaction Discovery · Reaction screening

Scripps Research · [NSF award 2607628](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607628)

**Candidate task.** Rank candidate conditions after detecting a missing internal standard.

- Rank reaction conditions by observed outcomes within a constrained design space. [Summit](https://doi.org/10.1002/cmtd.202000051)
- Hide subsequent experimental decisions to evaluate the next action. [Gamow LabBench](https://gamowlabs.com/labbench-benchmarking-ai-wet-lab-decisions)

**Node adaptation.** Expose internal-standard diagnostics, injection order and quality flags. Ask the agent to rank measurable conditions and identify samples that require reinjection.

**Minimum evidence request.** One deidentified screen, chromatograms or peak areas and standards, an internal-standard-missing example, and at least one independently measured replicate.

**Held-out check.** Keep all injections of one reaction condition together. Run a paired missing-standard case and score the decision to withhold an invalid yield before comparing valid ranks.

<a id="award-2607613"></a>

## PoLARIS · Polymer science

University of Chicago · [NSF award 2607613](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607613)

**Candidate task.** Choose the next polymer composition after a replicated property disagrees.

- Benchmark experiment planning against simple optimization policies with equal budgets. [Olympus](https://doi.org/10.1088/2632-2153/abedc8)
- Fork an otherwise identical observation process to isolate a hidden perturbation. [ChemWorld](https://arxiv.org/abs/2608.10792)

**Node adaptation.** Represent polymer composition, processing history and repeatability separately. Charge a repeat and a novel composition against the same approved experiment budget.

**Minimum evidence request.** A small composition–property table with batch labels, replicate values, tolerances and a costed set of allowed next interventions.

**Held-out check.** Hold out synthesis batches. Create one technical outlier and one reproducible batch shift and compare the value of a repeat against testing a new composition.

<a id="award-2607581"></a>

## PCL-AIMMPF · Materials manufacturing

Georgia Tech · [NSF award 2607581](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607581)

**Candidate task.** Compare manufacturing settings using matched reference coupons.

- Compare derived quality-control artifacts with independent reference analysis. [BixBench3](https://arxiv.org/abs/2608.25286)
- Model uncertainty in measured material properties rather than treating each observation as an exact label. [Olympus](https://doi.org/10.1088/2632-2153/abedc8)

**Node adaptation.** Make coupons, lots and processing conditions first-class entities. Require a matched reference coupon before classifying a manufacturing setting as out of specification.

**Minimum evidence request.** A deidentified lot with test and reference coupons, the traceable measurement method, matching rules, uncertainty estimates and a specification boundary.

**Held-out check.** Hold out a whole production lot. Include an otherwise plausible reference from a different lot and measure false out-of-spec alerts around the boundary.

<a id="award-2607526"></a>

## AIMD-NET · Structural materials

Johns Hopkins University · [NSF award 2607526](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607526)

**Candidate task.** Route alloy samples for follow-up tests after uncertainty in a property estimate.

- Choose the next query using a costed experiment-planning policy. [Olympus](https://doi.org/10.1088/2632-2153/abedc8)
- Evaluate the decision at a historical cutoff with later results withheld. [Gamow LabBench](https://gamowlabs.com/labbench-benchmarking-ai-wet-lab-decisions)

**Node adaptation.** Give the agent alloy sample histories, batch membership and candidate follow-up tests with different uncertainties and destructive-use costs.

**Minimum evidence request.** A small traceable alloy/processing series with repeated property measurements, one later confirmatory result, test costs and sample availability.

**Held-out check.** Hold out a heat or production batch. Compare reduction in held-out prediction error per sample consumed, including an option to defer if evidence cannot separate treatments.

<a id="award-2607469"></a>

## ATHENA · Nanoscale microscopy

University of Tennessee, Knoxville · [NSF award 2607469](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607469)

**Candidate task.** Reacquire a scan region after simulated tip drift degrades an image.

- Coordinate scan settings, acquisition and image analysis. [AFMBench](https://doi.org/10.1038/s41467-025-64105-7)
- Use repeatable scanning-probe tasks with instrument state. [q-devBench](https://arxiv.org/abs/2610.41717)
- Expose feedback-driven retuning during acquisition. [LabOSBench](https://arxiv.org/abs/2606.16802)

**Node adaptation.** Inject or replay a documented drift event and charge a time or area cost for reacquisition. Distinguish sample features from motion artifacts.

**Minimum evidence request.** A before/after scan pair with a fiducial or registration reference, scan-coordinate metadata, typical drift magnitudes and operator-accepted reacquisition bounds.

**Held-out check.** Hold out a scan session and its spatially adjacent patches. Check registration and usable area after recovery against withheld landmarks.

<a id="award-2607533"></a>

## ICoN-PCL · Low-dimensional materials

Purdue University · [NSF award 2607533](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607533)

**Candidate task.** Select a follow-up probe to distinguish two candidate material states.

- Expose real experimental control concepts through virtual instruments. [q-devBench](https://arxiv.org/abs/2610.41717)
- Choose interventions that discriminate between hidden hypotheses. [DiscoveryWorld](https://papers.nips.cc/paper_files/paper/2024/hash/13836f251823945316ae067350a5c366-Abstract-Datasets_and_Benchmarks_Track.html)

**Node adaptation.** Represent two candidate low-dimensional material states with overlapping evidence from one probe. Let the agent select a second probe or return an inconclusive call.

**Minimum evidence request.** Paired probe measurements on matched samples, independent reference states, calibration details and operating bounds for the proposed probe.

**Held-out check.** Withhold a specimen and all its modalities together. Compare discrimination on separable cases and escalation on specimens remaining ambiguous after the allowed measurements.

<a id="award-2607580"></a>

## Self-Driving Nanofab · Nanofabrication

Virginia Tech · [NSF award 2607580](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607580)

**Candidate task.** Reschedule a fabrication and metrology queue after a tool becomes unavailable.

- Use a hardware graph to enforce module availability and procedural precedence. [Programmable chemical synthesis](https://doi.org/10.1126/science.abc2986)
- Check the state required for individual instrument operations. [LabOSBench](https://arxiv.org/abs/2606.16802)

**Node adaptation.** Represent a wafer, process windows, metrology and a scheduled outage. Restrict routing to node-reviewed tool compatibility and hold-time limits.

**Minimum evidence request.** A sanitized process traveler, tool capability and outage records, a time-window constraint, and a measured dimension with its metrology uncertainty.

**Held-out check.** Hold out an outage pattern or tool pairing. Reject a schedule that meets its deadline by violating precedence, and validate predicted dimensions only on a matched measured part.

<a id="award-2607536"></a>

## LATTICE · Thin films

Penn State · [NSF award 2607536](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607536)

**Candidate task.** Identify a thickness gradient from spatially sparse metrology and choose new sites.

- Select spatial measurement points under an instrument action budget. [q-devBench](https://arxiv.org/abs/2610.41717)
- Compare adaptive sampling against an equal-budget baseline. [Olympus](https://doi.org/10.1088/2632-2153/abedc8)

**Node adaptation.** Provide sparse wafer sites and allow selection of new metrology locations. Use the node’s coordinate convention, edge exclusion and thickness uncertainty.

**Minimum evidence request.** A dense reference wafer map, the corresponding sparse sample sites, stage limits or forbidden regions, and a repeat-measurement noise estimate.

**Held-out check.** Hold out an entire wafer. Hide regions inside it until final scoring and compare prediction error, edge coverage and measurements consumed.

<a id="award-2607577"></a>

## Electronics Prototyping · Electronics

ADOM Industries · [NSF award 2607577](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607577)

**Candidate task.** Estimate component resistance from a simulated sweep with a bad contact.

- Retain instrument-compliance constraints and swept electrical measurements. [q-devBench](https://arxiv.org/abs/2610.41717)
- Grade violations over the entire trajectory even if the end estimate is accurate. [SafeLab](https://proceedings.mlr.press/v306/bai26e.html)

**Node adaptation.** Use a node-reviewed contact model and signed current or voltage sweeps. Ask the agent to diagnose a bad contact, respect compliance and estimate component resistance.

**Minimum evidence request.** A sweep on a known component, an offset or open-contact example, approved compliance limits and an independently calibrated reference resistance.

**Held-out check.** Withhold one component lot or fixture. Compare estimates before and after contact recovery and check whether any command exceeded the allowed envelope.

<a id="award-2607553"></a>

## READINESS · Semiconductor synthesis

Rice University · [NSF award 2607553](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607553)

**Candidate task.** Choose a follow-up characterization after a candidate film misses its target.

- Close a materials synthesis loop using independent characterization evidence. [A-Lab](https://doi.org/10.1038/s41586-023-06734-w)
- Check structural plausibility before accepting a numerical fit. [XRDBench](https://arxiv.org/abs/2609.00070)
- Compare candidate choices under a finite experimental budget. [Summit](https://doi.org/10.1002/cmtd.202000051)

**Node adaptation.** Choose a follow-up test for a semiconductor film that missed a target property. Link each available technique to an operator-reviewed hypothesis and cost.

**Minimum evidence request.** A film batch with preparation metadata, one approved structural or electronic characterization, a confirmatory property measurement and availability or cost for each probe.

**Held-out check.** Hold out a deposition batch. Verify candidate order against matched follow-up measurements and give credit for unresolved calls when the available characterization is nonidentifying.

<a id="award-2607535"></a>

## AURORA · Quantum materials

University of Utah · [NSF award 2607535](https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2607535)

**Candidate task.** Decide whether a stacked flake is aligned well enough for transport measurement.

- Tie measurement readiness to stateful transport-instrument controls. [q-devBench](https://arxiv.org/abs/2610.41717)
- Use image-based questions to check whether a visible physical state supports the next action. [BEAKER](https://arxiv.org/abs/2611.06911)

**Node adaptation.** Replace generic scene understanding with flake-edge alignment and a node-approved decision about proceeding to transport measurements. Permit escalation for ambiguous images.

**Minimum evidence request.** Registered images of aligned, misaligned and ambiguous stacks, pixel scale, operator annotations and the tolerance used before transfer to a measurement stage.

**Held-out check.** Keep every crop and repeat image from the same stack in one split. Compare angular or positional error and the rate of approving out-of-tolerance stacks.

## What a contributor can submit

Start with one workflow and one decision that a scientist at your node needs to make. A public description or a synthetic trace is enough to discuss a design. Moving it into a validated benchmark requires permissioned evidence and a reviewer who can distinguish a good run from a plausible-looking failure.

| Intake field | Example for a plate-reader workflow |
| --- | --- |
| Scientific decision | Decide whether the plate supports a concentration–response estimate. |
| Operator-visible evidence | Plate map, sample identifiers, concentration units, control wells and raw RFU. |
| Hidden reference and owner | An independently calculated fit and an operator assessment linked by a blind plate ID. |
| Allowed actions and cost | Read a plate, inspect controls, repeat a run or flag it for review. Provide the local time and sample cost. |
| Acceptance and indeterminate cases | Define the rule for control failure, fit tolerance and an unidentifiable midpoint before evaluation. |
| Split and access | Group every replicate from the same plate, variant and acquisition batch as required by the scientific claim. State who may access the raw data, derivatives and grading keys. |

**Example split.** At two approved sites measuring the same reference material, freeze the adapter interface and grading rules using site A. Tune only on site A development runs. Keep the reference outcomes, entire plates, specimen families and acquisition sessions for site B hidden from policy development. Give the agent site B’s public device manual and permitted calibration material. Evaluate both an in-site held-out batch and the held-out site, reporting unit conversion failures, invalid controls and numerical errors separately. With only one participating site this design supports a within-site evaluation. A cross-site result requires a second independently reviewed site and matched evidence.
