# Adding an adapter

## Prototype extension

Run `python -m examples.node_adapter` to register an original thin-film measurement and inspect its initial observation. The [working example](../examples/node_adapter.py) uses the public `Task` and `register_task` API and requires no modification to package files.

1. Specify a stable ID, instrument, objective, unit/tolerance, acquisition points, valid settings, fault and recovery action. Provide provenance through the required node, source, permission and validation fields. Use a redacted source identifier for restricted material. The metadata is exposed in observations.
2. Implement `model(rng, point)` returning a measurement and hidden target. A fresh RNG with the same seed is supplied for each acquisition, so draw shared latent parameters in the same order. The hidden target must stay constant throughout an episode.
3. Call `register_task(...)` in the process that will host the environment, then initialize `Environment(identifier, seed=..., condition='clean' or 'fault')`. Use `step()` to integrate your policy. Registration rejects duplicate IDs. It is process-local, and includes only code trusted by the host. The bundled control matrix and policies apply to the three built-in instruments. A new adapter should bring its own reference analysis, controls and acceptance tests.

## Partner contribution checklist

A participant can share a redacted protocol description without sending its full SOP. Record the rights holder, authorized use, source/version, scientific owner, instrument model or capability profile, allowable units/ranges, control samples, and known failure classes. Maintain a local review record linking claims about timing, uncertainty, data and recovery to evidence. Assign distinct stages to **synthetic**, **reviewed specification**, **trace-calibrated simulation** and **prospectively validated** assets. Mark unmeasured parameters explicitly. Keep access-controlled material out of public pull requests.

Before a cross-node release, jointly specify what is graded and who saw each protocol. Split at the node, instrument and protocol levels before generating variants. Keep derivatives, trace excerpts and several versions of the same SOP in one partition. Record expert reference decisions, any known ambiguities, replay data provenance and a sensitivity analysis for hidden parameters. Use numeric grading only where an evidence-based tolerance is meaningful.

A new protocol that needs asynchronous events, multi-step device orchestration, stochastic noise, images, external files, multiple acceptable plans or expert scoring will need a new environment implementation beyond the scalar starter interface. The public `observe()` / `step()` boundary and JSON session convention can be preserved.
