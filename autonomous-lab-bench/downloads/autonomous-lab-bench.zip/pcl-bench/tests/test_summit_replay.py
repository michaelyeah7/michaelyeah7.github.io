import tempfile
import unittest
from pathlib import Path

from adapters.summit_replay.replay import Campaign, baseline, read_case


class ReplayTests(unittest.TestCase):
    def setUp(self):
        self.data = {('X', 10*j, j+10, 1): float(j) for j in range(12)}

    def test_blinded_actions_and_budget(self):
        env = Campaign(self.data, budget=2)
        self.assertEqual(env.observe()['observations'], [])
        self.assertEqual(env.query(0), 0.0)
        with self.assertRaises(ValueError):
            env.score()
        with self.assertRaises(ValueError):
            env.query(0)
        env.query(1)
        self.assertEqual(env.score(), {'best_yield_pct': 1.0, 'simple_regret_pp': 10.0})
        with self.assertRaises(ValueError):
            env.query(2)

    def test_common_warm_start_and_replay(self):
        for seed in range(6):
            self.assertEqual(baseline(self.data, seed, 'random', budget=3),
                             baseline(self.data, seed, 'local-greedy', budget=3))
            self.assertEqual(baseline(self.data, seed, 'local-greedy'),
                             baseline(self.data, seed, 'local-greedy'))

    def test_checksum_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d, 'reizman_suzuki_case_1.csv').write_bytes(b'modified')
            with self.assertRaisesRegex(ValueError, 'Checksum mismatch'):
                read_case(1, d)
