import unittest

from pclbench import Environment, TASKS
from pclbench.controls import run, summarize
from pclbench.policies import decide


class ProtocolTests(unittest.TestCase):
    def test_20_seeds_all_families(self):
        for task in TASKS:
            for seed in range(20):
                r = run(task, seed, 'reference')
                self.assertTrue(r['success'])
                self.assertEqual(r['recoveries'], 1)
                self.assertFalse(run(task, seed, 'no-recovery')['success'])

    def test_safety_interlock_disqualifies_eventual_answer(self):
        for task in TASKS:
            e = Environment(task)
            setting = next(iter(e.spec.limits))
            self.assertEqual(e.step({'op': 'configure', 'settings': {setting: -100}})['status'], 'interlock')
            while not e.done:
                e.step(decide(e.observe()))
            self.assertTrue(e.result['accurate'])
            self.assertFalse(e.result['success'])

    def test_guessing_truth_without_evidence(self):
        e = Environment('absorbance-peak')
        e.step({'op': 'submit', 'estimate': 460})
        self.assertEqual(e.result['coverage'], 0)
        self.assertFalse(e.result['success'])
        with self.assertRaises(RuntimeError):
            e.step({})

    def test_invalid_calls_and_budget(self):
        e = Environment('iv-resistance', budget=3)
        self.assertEqual(e.step({'op': 'measure'})['status'], 'configure_first')
        self.assertEqual(e.step({'op': 'recover'})['status'], 'invalid_recovery')
        self.assertEqual(e.step({})['status'], 'budget_exhausted')

    def test_paired_fault_recovery_and_analysis_controls(self):
        for task in TASKS:
            clean = run(task, 11, 'no-recovery', condition='clean')
            fault = run(task, 11, 'no-recovery')
            self.assertTrue(clean['success'])
            self.assertIsNone(fault['absolute_error'])
            shortcuts = [run(task, 11, 'shortcut-analysis', condition=c) for c in ('clean', 'fault')]
            self.assertEqual(shortcuts[0]['absolute_error'], shortcuts[1]['absolute_error'])
            self.assertGreater(shortcuts[1]['absolute_error'], TASKS[task].tolerance)
            self.assertEqual(shortcuts[0]['coverage'], 1)
            self.assertEqual(shortcuts[1]['recoveries'], 1)
            self.assertEqual(summarize([fault])[0]['submitted_estimates'], 0)

    def test_public_adapter(self):
        from examples.node_adapter import register
        from pclbench.tasks import PROVENANCE
        identifier = register()
        self.addCleanup(TASKS.pop, identifier)
        self.addCleanup(PROVENANCE.pop, identifier)
        with self.assertRaises(ValueError):
            register()
        env = Environment(identifier, condition='clean')
        self.assertEqual(env.observe()['provenance']['validation'], 'synthetic')
        env.step({'op': 'configure', 'settings': {'exposure_ms': 10}})
        for point in ('dark', 'reference', 'film'):
            env.step({'op': 'measure', 'point': point})
        v = {r['point']: r['value'] for r in env.observe()['readings']}
        env.step({'op': 'submit', 'estimate': 100*(v['film']-v['dark'])/(v['reference']-v['dark'])})
        self.assertTrue(env.result['success'])

    def test_determinism(self):
        for task in TASKS:
            first, second = [], []
            run(task, 9, 'reference', first)
            run(task, 9, 'reference', second)
            self.assertEqual(first, second)


if __name__ == '__main__':
    unittest.main()
